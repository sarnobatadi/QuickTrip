boldFont = 'Mulish-SemiBold';
baseFont = 'Mulish-Regular';
liteFont = 'Mulish-Bold';
extraFont = 'Mulish-ExtraBold'

const baseUrl = "http://127.0.0.1:8000/"

export default {baseUrl}
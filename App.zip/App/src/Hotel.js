import React from 'react'
import { Text } from 'react-native'

const Hotel = () => {
    return (
        <Text>dhue</Text>
    )
}

export default Hotel
